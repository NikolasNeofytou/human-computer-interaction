import 'package:todotoday/task.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:logging/logging.dart';

class SQLService {
  // https://docs.flutter.dev/cookbook/persistence/sqlite
  // our logger
  final log = Logger('SQLServiceLogger');

  Database? _database;
  String dbfile = "tasks.db";


  Future<Database> get database async {
    
    
    if (_database != null) {
     log.config("get database called, return instance");
      return _database!;
    }
    _database = await initDB();
    //initWinDB();
    log.config("get database called, return initDB");
    return _database!;
  }

   //In memory database
  Future<Database> initWinDB() async {
    sqfliteFfiInit();
    final databaseFactory = databaseFactoryFfi;
    return await databaseFactory.openDatabase(
      inMemoryDatabasePath,
      options: OpenDatabaseOptions(
        onCreate: _onCreate,
        version: 1,
      ),
    );
  }

  // Platform Specific

  Future<Database> initDB() async {
    log.config("initDB called, Platform ${Platform.operatingSystem}");
    if (Platform.isWindows || Platform.isLinux) {
       /* https://stackoverflow.com/questions/76158800/databasefactory-not-initialized-when-using-sqflite-in-flutter */
      sqfliteFfiInit();
      // Change the default factory      
      final databaseFactory = databaseFactoryFfi;
      final appDocumentsDir = await getApplicationDocumentsDirectory();
      final dbPath = join(appDocumentsDir.path, "databases", dbfile);
      final winLinuxDB = await databaseFactory.openDatabase(
        dbPath,
        options: OpenDatabaseOptions(
          version: 1,
          onCreate: _onCreate,
        ),
      );
      return winLinuxDB;
    } else if (Platform.isAndroid || Platform.isIOS || Platform.isMacOS) {
      final documentsDirectory = await getApplicationDocumentsDirectory();
      final path = join(documentsDirectory.path, dbfile);
      final iOSAndroidDB = await openDatabase(
        path,
        version: 1,
        onCreate: _onCreate,
      );
      return iOSAndroidDB;
    }
    throw Exception("Unsupported platform");
  }

  Future<void> _onCreate(Database database, int version) async {
    final db = database;
    
    log.config("_onCreate called [version:${version}, path:${db.path}]");
    await db.execute(
        'CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, description TEXT, isdone INTEGER, tasktime TEXT)');
  }

  /*  method that inserts tasks into the database */
  Future<int> insertTask(Task task) async {
    log.config("insertTask to DB task.toJson(): ${task.toJson()}");

    // Get a reference to the database.
    //final db = await initDB();
    final db = await database;
    // Insert the Task into the correct table. You might also specify the
    // `conflictAlgorithm` to use in case the same Task is inserted twice.
    // In this case, replace any previous data.
    return await db.insert(
      'tasks',
      task.toJson(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  /* method that retrieves all tasks from the tasks table. */
  Future<List<Task>> getTasks() async {
    log.config("getTasks called");
    // Get a reference to the database.
    final db = await database;

    // Query the table for all tasks.
    final List<Map<String, dynamic>> queryResult = await db.query('tasks');

    // Μετατροπή τους από εγγραφές ΒΔ σε στιγμιότυπα κλάσης [Task]
    return queryResult.map((e) => Task.fromJson(e)).toList();
  }

  /* method that updates a given task  */
  Future<int> updateTask(Task task) async {
    log.config("updateTask to DB task(): ${task.toString()}");
    
    // Get a reference to the database.
    final db = await database;

    // Update the given task.
    return await db.update(
      'tasks',
      task.toJson(),
      // Ensure that the task has a matching id.
      where: 'id = ?',
      // Pass the tasks's id as a whereArg to prevent SQL injection.
      whereArgs: [task.id],
    );
  }

  /* method that deletes a given task  */
  Future<int> deleteTask(Task task) async {
    log.config("deleteTask to DB task.toJson(): ${task.toString()}");
    
    // Get a reference to the database.
    final db = await database;

    // Remove the task from the database.
    return await db.delete(
      'tasks',
      // Use a `where` clause to delete a specific task.
      where: 'id = ?',
      // Pass the tasks's id as a whereArg to prevent SQL injection.
      whereArgs: [task.id],
    );
  }

 /* method that clears the tasks table */
  Future<int> deletAllTasks() async {
    // Get a reference to the database.
    final db = await database;
    return await db.rawDelete("DELETE FROM TASKS");
  }
}

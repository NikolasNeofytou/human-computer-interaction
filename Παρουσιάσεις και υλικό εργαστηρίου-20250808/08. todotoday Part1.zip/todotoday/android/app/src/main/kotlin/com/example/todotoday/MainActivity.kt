package com.example.todotoday

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

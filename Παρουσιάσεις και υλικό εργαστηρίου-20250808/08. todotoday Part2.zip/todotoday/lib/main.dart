import 'dart:async';
import 'package:flutter/material.dart';
import 'package:logging/logging.dart';
import 'package:camera/camera.dart';

import 'package:todotoday/SQLService.dart';
import 'package:todotoday/task.dart';
import 'package:todotoday/camera.dart';


final log = Logger('MainAppLogger');

/*
1. Data Table functionality
  1. DataRow Method   --> OK
  2. Sorting          --> OK 
2. Add/ Edit Task Screen 
  1. Edit Task Page   --> OK
  2. Add /Edit Form   --> OK
3. DataBase intergration
  1. SetUpDb        --> OK
  2. CRUD           --> OK  
4. UI fixes         --> OK
5. Camera screen    
  1. CameraScreenWidget --> OK
  2. text_recognition --> OK
*/

// Λίστα στην οποία πρόκειται να προστεθούν οι διαθέσιμες κάμερες της συσκευής.
// Το late υποδηλώνει ότι μπορεί να αρχικοποιηθεί και αργότερα (και όχι τώρα
// που δηλώνεται)
late List<CameraDescription> cameras;

// Μεταβλητή στην οποία θα αποθηκευτεί η κάμερα που θα επιλέξουμε
late CameraDescription firstCamera;

Future<void> main() async {
  // Προκειμένου να πάρουμε μια λίστα με τις διαθέσιμες κάμερες της συσκευής
  // πρέπει να βεβαιωθούμε ότι όλες οι υπηρεσίες των προσθέτων που χρησιμο-
  // ποιούμε (plugins) έχουν αρχικοποιηθεί πριν καλέσουμε την runApp()
  WidgetsFlutterBinding.ensureInitialized();

  // Λήψη λίστας με τις διαθέσιμες κάμερες της συσκευής
  cameras = await availableCameras();

  // Από τη λίστα που έχει επιστραφεί, παίρνουμε την πρώτη κάμερα
  firstCamera = cameras.first;

  Logger.root.level = Level.ALL; // defaults to Level.INFO
  Logger.root.onRecord.listen((record) {
    print(
        '${record.loggerName} --> ${record.level.name}: ${record.time}: ${record.message}');
  });
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // hide debug banner
      debugShowCheckedModeBanner: false,
      title: '2DoToday',
      theme: ThemeData(
        appBarTheme: AppBarTheme(
            backgroundColor: Color(0xff6200EE),
            foregroundColor: Colors.white //here you can give the text color
            ),
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(
            foregroundColor: Colors.white,
            backgroundColor: Color(0xff6200EE),
          ),
        ),
        //primarySwatch: Colors.blue,
        colorScheme: ColorScheme.fromSeed(seedColor: Color(0xff6200EE)),
        primaryColor: Color(0xff6200EE),

        // useMaterial3: true,
      ),
      home: const MyHomePage(title: '2DoToday'),
    );
  }
}

// Υλοποίηση της κεντρικής οθόνης εισόδου της εφαρμογής ως [StatelessWidget]
class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  
  late CameraController controller;

  late SQLService sqlService;
  /* αρχική λιστα των Task */
  List<Task> _tasks = []; //Task.getTasks(10);

  /* Μεταβλητές για ταξινόμηση της λίστας στο DataTable*/
  bool _sortAscending = false;
  int _sortColumnIndex = 0;

  // Αρχικοποίηση στιγμιοτύπου κλάσης
  @override
  void initState() {
    super.initState();

    // Αρχικοποίηση στιγμιοτύπου της κλάσης [SQLiteService] για τη δημιουργία
    // και σύνδεση με την SQLite βάση δεδομένων της εφαρμογής
    sqlService = SQLService();
    // φόρτωση της λίστας με τα tasks που πιθανώς να υπάρχουν στη βάση
    sqlService.getTasks().then((value) => setState(() {
          _tasks = value;
        }));

    // Αρχικοποίηση του ελεγκτή κάμερας [CameraController] για σύνδεση με την
    // πρώτη κάμερα.
    controller = CameraController(cameras[0], ResolutionPreset.max);
    controller.initialize().then((_) {
      if (!mounted) {
        return;
      }
      setState(() {});
    });   
  }

  // Καταστροφή στιγμιοτύπου κλάσης
  @override
  void dispose() {
    /// Απελευθέρωση της κάμερας
    controller.dispose();

    /// Τέλος, καλούμε την dispose της υπερκλάσης
    super.dispose();
  }
  
  /*Βοηθητική μέθοδος για ταξινόμηση της λίστας με βάση την θέση (sortColumnIndex) και κατεύθυνση (sortAscending) */
  _sortTasks(int sortColumnIndex, bool sortAscending) {
    if (sortColumnIndex == 0) {
      _tasks.sort((a, b) => (sortAscending)
          ? (a.isDone == b.isDone)
              ? 0
              : (a.isDone ? 1 : -1)
          : (a.isDone == b.isDone)
              ? 0
              : (b.isDone ? 1 : -1));
    } else if (sortColumnIndex == 1) {
      _tasks.sort((a, b) => (sortAscending)
          ? a.title.compareTo(b.title)
          : b.title.compareTo(a.title));
    } else if (sortColumnIndex == 2) {
      _tasks.sort((a, b) => (sortAscending)
          ? a.taskTime!.hour * 60 +
              a.taskTime!.minute -
              b.taskTime!.hour * 60 -
              b.taskTime!.minute
          : b.taskTime!.hour * 60 +
              b.taskTime!.minute -
              a.taskTime!.hour * 60 -
              a.taskTime!.minute);
    }
    /* Πρέπει να την καλώ κάθε φορά που θέλω να αλλάξω κάτι και πρέπει να ξανασχεδιαστεί το UI βάση του αποτελέσματος */
    setState(() {
      _sortAscending = sortAscending;
      _sortColumnIndex = sortColumnIndex;
      log.config(
          "sort pressed [ColumnIndex:$sortColumnIndex, Ascending:$sortAscending]");
    });
  }

/*  Βοηθητική μέθοδος για την προσθήκη Task στην ΒΔ και στην λίστα */
  void _addTask(Task? task) {
    if (task != null) {
      log.config("_addTask requested for $task");
      _tasks.add(task);
      setState(() {});
      sqlService.insertTask(task).then((value) => {
            task.id = value,
            log.config("inserted task : $task"),
          });
    }
  }

  /*  Βοηθητική μέθοδος για την διαγραφή όλων των tasks */
  void _deleteAllTasks() {
    log.config("_deleteTasks requested ");
    sqlService.deletAllTasks().then((value) => {
          log.config("_deleteTasks returned : $value"),
          _tasks.clear(),
          setState(() {})
        });
  }

/*  Βοηθητική μέθοδος για την ενημέρωση Task στην ΒΔ */
  void _update(Task task) {
    log.config("_update requested for $task");
    sqlService.updateTask(task).then((value) => {
          setState(() {
            log.config("updated task : $task");
          })
        });
  }

  /*Βοηθητική μέθοδος για την διαγραφή Task  */
  void _deleteTask(task) {
    log.config("delete requested for $task");
    sqlService.deleteTask(task).then((value) => {
          log.config("deleted task : $task"),
          _tasks.remove(task),
          setState(() {})
        });
  }

  /*Βοηθητική μέθοδος για την διαγραφή όλων των checked tasks */
  void _deleteCheckedTasks() {
    log.config("_deleteCheckedTasks requested ");
    _tasks.forEach((element) {
      if (element.isDone) {
        _deleteTask(element);
      }
    });
  }

  /*Βοηθητική μέθοδος για την επικύρωση του χρήστη */
  Future<bool?> confirmDelete() {
    Future<bool?> delTask = showDialog<bool>(
        context: context,
        builder: (BuildContext context) => AlertDialog(
              content: const Text('Delete Task?'),
              actions: <Widget>[
                // Αν επιλεγεί το Cancel επιστρέφεται false
                TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text('Cancel')),

                // Αν επιλεγεί το Yes επιστρέφεται true
                TextButton(
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text('Yes')),
              ],
            ));

    return delTask;
  }

  /*Βοηθητική μέθοδος για την διαγραφη task */
  checkDelete(Task mytask) {
    confirmDelete().then((value) {
      if (value != null && value) {
        log.config("delete confirmed for $mytask");
        _deleteTask(mytask);
      }
    });
  }

/*Βοηθητική μέθοδος για κατασκευή λίστας DataRow με βάση την αρχική λιστα των Task */
  List<DataRow> _getDataRow() {
    List<DataRow> retVal = [];
    for (var mytask in _tasks) {
      retVal.add(DataRow(cells: <DataCell>[
        DataCell(
          Checkbox(
            value: mytask.isDone,
            onChanged: (value) => {
              log.config("isDone changed for $mytask"),
              mytask.isDone = value!,
              _update(mytask)
            },
          ),
        ),
        DataCell(Text(
          mytask.title,
          // dynamically change the text style if isDone is true
          style: mytask.isDone
              ? TextStyle(
                  color: Colors.grey, decoration: TextDecoration.lineThrough)
              : null,
        )),
        DataCell(Text(
          mytask.formatTime(),
          // dynamically change the text style if isDone is true
          style: mytask.isDone
              ? TextStyle(
                  color: Colors.grey, decoration: TextDecoration.lineThrough)
              : null,
        )),
        DataCell(IconButton(
          icon: const Icon(Icons.delete),
          onPressed: () => checkDelete(mytask),
        )),
      ]));
    }
    return retVal;
  }

  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called
    return Scaffold(
      appBar: AppBar(
        leading: PopupMenuButton<Text>(
          icon: const Icon(Icons.menu),
          itemBuilder: (context) {
            return [
              PopupMenuItem(
                child: Text("Clear Checked"),
                onTap: _deleteCheckedTasks,
              ),
              PopupMenuItem(
                child: Text("Clear All"),
                onTap: _deleteAllTasks,
              ),
              PopupMenuItem(
                child: Text("Order by Time"),
                onTap: () => {_sortTasks(2, !_sortAscending)},
              ),
              PopupMenuItem(
                child: Text("Order by Name"),
                onTap: () => {_sortTasks(1, !_sortAscending)},
              ),
            ];
          },
        ),
        title: Text("Task List"),
        actions: [
          IconButton(
            tooltip: "Car Mode",
            icon: Image.asset('assets/images/steering-wheel.png'),
            onPressed: () {},
          ),
          

          // Κουμπί μετάβασης στην οθόνη της κάμερας
          IconButton(
            onPressed: () {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) =>

                      // Περάνμε ως παράμετρο στο [CameraScreenWidget] την
                      // πρώτη κάμερα της συσκευής που αναγνωρίσαμε
                      CameraScreenWidget(camera: firstCamera)));
            },
            icon: Image.asset('assets/images/camera.png'),
            tooltip: 'Camera',
          ),

          // )
        ],
      ),
      body: ListView(
        
        padding: const EdgeInsets.all(8),
        children: [
          DataTable(
            // εάν δεν θέλω να εμφανίζονται οι κεφαλίδες
            // headingRowHeight: 0,
            sortAscending: _sortAscending,
            sortColumnIndex: _sortColumnIndex,
            columnSpacing: 0, // απόσταση μεταξύ των στηλών
            columns: <DataColumn>[
              DataColumn(
                label: Text('Επιλογή'),
                onSort: (columnIndex, ascending) =>
                    {_sortTasks(columnIndex, ascending)},
              ),
              DataColumn(
                label: Text('Title'),
                onSort: (columnIndex, ascending) =>
                    {_sortTasks(columnIndex, ascending)},
              ),
              DataColumn(
                label: Text('Time'),
                onSort: (columnIndex, ascending) =>
                    {_sortTasks(columnIndex, ascending)},
              ),
              DataColumn(
                label: Text('Delete'),
              ),
            ],
            rows: _getDataRow(), // φέρε τα δεδομένα από την λίστα των tasks
          ),
        ],
      ),

      // Μπάρα στο κάτω μέρος της οθοόνης ([BottomAppBar])
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            IconButton(onPressed: () {}, icon: const Icon(null))
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.teal,
        onPressed: () {
          Navigator.push<Task>(
            context,
            MaterialPageRoute(builder: (context) => const TaskDetails()),
          ).then(_addTask);
          ///to avoid any np exception you can do this: .then(onGoBack ?? () => {})
        },
   
        tooltip: 'Προσθήκη νέου task',
        child: const Icon(Icons.add),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endDocked,
    );
  }
}

class TaskDetails extends StatefulWidget {
  const TaskDetails({super.key});

  @override
  State<TaskDetails> createState() => _TaskDetailsState();
}

class _TaskDetailsState extends State<TaskDetails> {
  // Create a global key that uniquely identifies the Form widget
  // and allows validation of the form.
  final _formKey = GlobalKey<FormState>();
  /* Μεταβλητή για την επιλεγμένη ώρα */
  TimeOfDay? _taskTime;
  /* validator για τον έλεγχο των πεδίων */
  var titleEditingController = TextEditingController();
  /* validator για τον έλεγχο των πεδίων */
  var descEditingController = TextEditingController();

  // Καταστροφή στιγμιοτύπου κλάσης
  @override
  void dispose() {
    // Απελευθέρωση των πόρων που δέσμευσαν οι [TextEditingController]
    titleEditingController.dispose();
    descEditingController.dispose();
    // Τέλος, καλούμε την dispose της υπερκλάσης
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Build a Form widget using the _formKey created above.

    return Scaffold(
      appBar: AppBar(
        title: const Text('View / Edit Task'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  maxLines: 1,
                  // The validator receives the text that the user has entered.
                  validator: validateText,
                  controller: titleEditingController,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    // labelText: "Enter Title"
                    hintText: "Enter Title",
                  ),
                ),
              ),
              const SizedBox(width: 50, height: 50),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  maxLines: 5,
                  // The validator receives the text that the user has entered.
                  validator: validateText,
                  controller: descEditingController,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    //labelText: "Enter Description",
                    hintText: "Enter Description",
                  ),
                ),
              ),
              const SizedBox(width: 50, height: 50),
              Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.notifications),
                    onPressed: () => _selectTaskTime(),
                  ),

                  /* το Offstage κρύβει τα παιδιά του ανάλογα με την συνθήκη */
                  // εμφάνιση επιλεγμένης ώρας
                  Offstage(
                    offstage: _taskTime == null,
                    child: Text(_taskTime != null
                        ? "${_taskTime?.hour}:${_taskTime?.minute}"
                        : ""),
                  ),
                  // διαγραφή επιλεγμένης ώρας
                  Offstage(
                    offstage: _taskTime == null,
                    child: IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () {
                        setState(() {
                          _taskTime = null;
                        });
                      },
                    ),
                  ),
                  const Spacer(),
                  ElevatedButton(
                    onPressed: () {
                      log.config("Cancel pressed");
                      Navigator.pop(context);
                    },
                    child: const Text('Cancel'),
                  ),
                  Padding(padding: const EdgeInsets.all(10)),
                  ElevatedButton(
                    onPressed: () {
                      // Validate returns true if the form is valid, or false otherwise.
                      if (_formKey.currentState!.validate() &&
                          _taskTime != null) {
                        log.config(
                            "form validated [title: ${titleEditingController.text}, description: ${descEditingController.text}]");
                        // επιστρέφω νέο task με βάση τις τιμές του χρήστη.
                        Navigator.pop(
                            context,
                            Task(null, titleEditingController.text,
                                descEditingController.text, false, _taskTime));
                      }
                    },
                    child: const Text('Save'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  /* Βοηθητική μέθοδος για την επιστρο΄φη TimeOfDay από τον χρήστη μέσω της _taskTime*/
  Future<void> _selectTaskTime() async {
    // Εμφάνιση του παραθύρου επιλογής ώρας alarm. Γdια περισσότερες πληροφορίες
    // σχετικές με date/time pickers ανατρέξτε στο documentation
    // https://m3.material.io/components/time-pickers/overview
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      setState(() {
        _taskTime = picked;
      });
    }
    log.config("_taskTime: ${_taskTime.toString()}");
  }

  /* Βοηθητική μέθοδος για τον έλεγχο της τιμής Text πεδίου*/
  String? validateText(value) {
    if (value == null || value.isEmpty) {
      return 'Παρακαλώ δώστε τιμή';
    }
    return null;
  }
}

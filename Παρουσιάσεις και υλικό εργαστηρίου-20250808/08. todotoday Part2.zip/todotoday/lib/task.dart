import 'dart:math';

import 'package:flutter/material.dart';
import 'package:logging/logging.dart';

final log = Logger('TaskLogger');

class Task {
  int? id;
  late String title;
  late String description;
  late bool isDone;
  TimeOfDay? taskTime;

  //Task(this.title, this.description, this.isDone, this.taskTime);// {}
  Task(int? id, String title, String description, bool isDone,
      TimeOfDay? taskTime) {
    this.id = id;
    this.title = title;
    this.description = description;
    this.isDone = isDone;
    this.taskTime = taskTime;
  }

  /* Constructor from json object */
  Task.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    description = json['description'];
    isDone = json['isdone'] == 1 ? true : false;
    taskTime = (json['tasktime'] != null)
        ? TimeOfDay(
            hour: int.parse(json['tasktime'].split(':')[0]),
            minute: int.parse(json['tasktime'].split(':')[1]))
        : null;
  }

  /* to json object */
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'isdone': isDone ? 1 : 0,
      'tasktime': formatTime()
    };
  }

  String formatTime() {
    return (taskTime != null)
        ? "${taskTime?.hour}:${taskTime?.minute.toString().padLeft(2, '0')}"
        : "";
  }

  @override
  String toString() {
    //return "Task:[id: $id, title: $title, description: $description, isDone: $isDone, taskTime: ${formatTime()}]";
    return "Task:[${toJson()}]";
  }

  static List<Task> getTasks(int howmany) {
    return List.generate(
        howmany,
        (index) => Task(
            index,
            "title:$index",
            "description: $index",
            (index % 2 == 0) ? false : true,
            TimeOfDay(
                hour: Random().nextInt(24), minute: Random().nextInt(59))));
  }
}

void main() {
  Logger.root.level = Level.ALL; // defaults to Level.INFO
  Logger.root.onRecord.listen((record) {
    print('${record.level.name}: ${record.time}: ${record.message}');
  });

  List<Task> mytasks = Task.getTasks(10);
  for (var task in mytasks) log.info("printing my task:$task");
}
